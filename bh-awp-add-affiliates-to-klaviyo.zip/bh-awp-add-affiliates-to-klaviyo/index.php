<?php
/**
 * Silence is golden.
 *
 * @package    BH_AWP_Add_Affiliates_to_Klaviyo
 */

die();
